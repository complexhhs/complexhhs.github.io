---
layout: notes
permalink: /notes
---
